const MESSAGES = {
    removeButton: "Remove",
    addButton: "Add Note",
    writerPageTitle: "Note Writer",
    readerPageTitle: "Note Reader",
    storedTime: "stored at: ",
};
